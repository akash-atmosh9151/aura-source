# Aura: notification edge glow

A wavy light that flows around your screen edge whenever a notification arrives.
Default style is dot-matrix (Nothing-inspired); Hybrid and Fluid (liquid light) are one tap away.
Every app can have its own color, or be switched off.

Needs Android 13 or newer (the glow is drawn by a GPU shader).

## Get the APK from your phone (no computer)

1. On GitHub, create a new repository (or reuse one).
2. **Add file → Upload files**, choose `aura-source.zip`, then **Commit**.
3. **Add file → Create new file**, name it `.github/workflows/build.yml`,
   paste in the contents of `build.yml`, then **Commit**.
4. Open the **Actions** tab. "Build Aura APK" takes about 4-6 minutes.
5. When it is green, open **Releases** on the repo page, open the newest
   "Aura build N", and tap **Aura.apk** to download and install it.
   (Android will ask once to allow installs from your browser.)

If you have a computer: unzip, `git init`, push. The workflow is already inside the zip
at `.github/workflows/build.yml`.

Every build is signed with the same key, so a new APK installs over the old one and
keeps your settings.

## First launch

1. Tap **Grant** on the three rows in the Setup card.
   - **Notification access** may be greyed out for a sideloaded app. Fix: App info,
     three dots at the top right, **Allow restricted settings**, then grant again.
     The card has an "Open app info" button for this.
2. Use **Preview on screen** to see the real thing.
3. Tune the look, then open any app in the list to give it its own color.

## If something goes wrong

- The in-app preview is blank and a red box shows an error: the glow shader did not
  compile on your phone. Send that text and it can be fixed quickly.
- Glow never appears for real notifications: check the Setup card is all "On", and
  that "Respect Do Not Disturb" is not hiding them.
- The build fails in Actions: open the failed run, copy the red lines near the end.
