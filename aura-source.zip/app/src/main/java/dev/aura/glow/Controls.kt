package dev.aura.glow

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Tap target with a small spring "press" scale. Apply it first in the chain so it scales everything after it. */
@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 700f),
        label = "tap",
    )
    val latest = rememberUpdatedState(onClick)
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { latest.value() },
            )
        }
}

/** Reports a 0..1 position while the finger is down on this element horizontally. */
@Composable
fun Modifier.scrubbable(onEnd: () -> Unit = {}, onFraction: (Float) -> Unit): Modifier {
    val cb = rememberUpdatedState(onFraction)
    val end = rememberUpdatedState(onEnd)
    return pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown()
            val w = size.width.toFloat().coerceAtLeast(1f)
            cb.value((down.position.x / w).coerceIn(0f, 1f))
            down.consume()
            drag(down.id) { change ->
                cb.value((change.position.x / w).coerceIn(0f, 1f))
                change.consume()
            }
            end.value()
        }
    }
}

@Composable
fun NSwitch(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val pos by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "switch",
    )
    Box(
        modifier
            .tap { onChange(!checked) }
            .size(width = 52.dp, height = 30.dp)
            .clip(CircleShape)
            .background(lerp(NC.Surface2, NC.White, pos))
            .border(1.dp, NC.Line, CircleShape),
    ) {
        Box(
            Modifier
                .padding(4.dp)
                .offset { IntOffset((22.dp.toPx() * pos).roundToInt(), 0) }
                .size(22.dp)
                .clip(CircleShape)
                .background(lerp(Color(0xFF6A6A6A), NC.Red, pos)),
        )
    }
}

/** A row of dots that fills up like a level meter. */
@Composable
fun DotSlider(
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onCommit: () -> Unit = {},
    dots: Int = 24,
) {
    val haptic = LocalHapticFeedback.current
    var lastStep by remember { mutableIntStateOf(-1) }
    Canvas(
        modifier
            .fillMaxWidth()
            .height(36.dp)
            .scrubbable(onEnd = onCommit) { f ->
                onChange(f)
                val step = (f * dots).roundToInt()
                if (step != lastStep) {
                    lastStep = step
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            },
    ) {
        val pitch = size.width / dots
        val r = (pitch * 0.30f).coerceAtMost(5.dp.toPx())
        val n = (value * dots).roundToInt()
        for (i in 0 until dots) {
            val on = i < n
            val tip = on && i == n - 1
            drawCircle(
                color = if (tip) NC.Red else if (on) NC.White else NC.Faint,
                radius = if (tip) r * 1.4f else r,
                center = Offset(pitch * (i + 0.5f), size.height / 2f),
            )
        }
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val outer = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(outer)
            .background(NC.Surface2)
            .border(1.dp, NC.Line, outer)
            .padding(4.dp),
    ) {
        options.forEachIndexed { i, text ->
            val sel = i == selected
            val bg by animateColorAsState(
                targetValue = if (sel) NC.White else Color.Transparent,
                label = "segment",
            )
            Box(
                Modifier
                    .weight(1f)
                    .tap { onSelect(i) }
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(bg),
                contentAlignment = Alignment.Center,
            ) {
                Label(
                    text,
                    color = if (sel) NC.Black else NC.Dim,
                    size = 11.sp,
                    weight = FontWeight.Bold,
                    spacing = 1.6.sp,
                )
            }
        }
    }
}

@Composable
fun NCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(NC.Surface)
            .border(1.dp, NC.Line, shape)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        content = content,
    )
}

@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
) {
    Box(
        modifier
            .tap(onClick)
            .height(40.dp)
            .clip(CircleShape)
            .background(if (filled) NC.White else Color.Transparent)
            .border(1.dp, if (filled) NC.White else NC.Faint, CircleShape)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Label(
            text,
            color = if (filled) NC.Black else NC.White,
            size = 11.sp,
            weight = FontWeight.Bold,
            spacing = 1.6.sp,
        )
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(NC.Line))
}

@Composable
fun SectionTitle(left: String, right: String = "") {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Label(left, color = NC.White, size = 11.sp, weight = FontWeight.Bold, spacing = 1.8.sp)
        Spacer(Modifier.weight(1f))
        if (right.isNotEmpty()) Label(right, size = 10.sp)
    }
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Body(title, size = 15.sp)
            Spacer(Modifier.height(2.dp))
            Body(sub, size = 12.sp, color = NC.Dim, weight = FontWeight.Normal)
        }
        NSwitch(checked, onChange)
    }
}

@Composable
fun SliderRow(
    name: String,
    value: Float,
    onChange: (Float) -> Unit,
    onCommit: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Label(name, color = NC.White, size = 11.sp)
            Spacer(Modifier.weight(1f))
            Label("${(value * 100).roundToInt()}", size = 11.sp)
            Spacer(Modifier.width(2.dp))
        }
        DotSlider(value = value, onChange = onChange, onCommit = onCommit)
    }
}
