package dev.aura.glow

import android.app.Application

class AuraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AuraStore.init(this)
    }
}
