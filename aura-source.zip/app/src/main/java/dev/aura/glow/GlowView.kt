package dev.aura.glow

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.os.SystemClock
import android.view.RoundedCorner
import android.view.View
import android.view.WindowInsets
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Draws the wavy edge glow with an AGSL shader.
 *
 * The animation is a small physical model rather than a fixed timeline: a target of 1 while a
 * glow is "held" and 0 afterwards, smoothed through two cascaded low-pass filters. That gives a
 * soft S-shaped swell and a long, silky fade, and it means a second notification arriving mid-way
 * simply keeps things lit and blends the colour, with no restart pop.
 */
class GlowView(context: Context) : View(context) {

    private val rt = RuntimeShader(GlowShader.source(context))
    private val paint = Paint().apply { shader = rt }
    private val density = resources.displayMetrics.density

    private var cfg = GlowConfig.fromStore()
    private val cur = FloatArray(15)
    private val from = FloatArray(15)
    private val to = FloatArray(15)
    private var colorT0 = 0L

    private var stage1 = 0f
    private var level = 0f
    private var holdUntil = 0L
    private var sweepStart = 0L
    private var lastFrame = 0L
    private val timeBase = SystemClock.uptimeMillis()

    private var running = false
    private var looping = false
    private var lastPalette = FloatArray(15)

    private var cornerPx = -1f

    /** When >= 0, used instead of the display's real corner radius (for the in-app preview). */
    var fixedCornerPx = -1f

    /** Called (on the main thread) once the glow has fully faded out. */
    var onFinished: (() -> Unit)? = null

    private val finishRunnable = Runnable {
        if (!running) onFinished?.invoke()
    }

    /** Play the preview loop's glow again right now (tap on the in-app preview). */
    fun replay() {
        if (looping) trigger(lastPalette, cfg)
    }

    /** Start a glow, or if one is already running keep it lit and blend to the new colours. */
    fun trigger(palette: FloatArray, config: GlowConfig, restartSweep: Boolean = true) {
        val now = SystemClock.uptimeMillis()
        cfg = config
        lastPalette = palette
        if (!running) {
            System.arraycopy(palette, 0, cur, 0, 15)
            stage1 = 0f
            level = 0f
            lastFrame = now
            sweepStart = now
        } else if (restartSweep) {
            sweepStart = now
        }
        System.arraycopy(cur, 0, from, 0, 15)
        System.arraycopy(palette, 0, to, 0, 15)
        colorT0 = now
        holdUntil = now + INTRO_MS + config.holdMs
        running = true
        invalidate()
    }

    /** In-app preview: loops forever and follows live setting changes. */
    fun runLoop(palette: FloatArray, config: GlowConfig) {
        cfg = config
        lastPalette = palette
        if (!looping) {
            looping = true
            trigger(palette, config)
        } else if (running) {
            System.arraycopy(cur, 0, from, 0, 15)
            System.arraycopy(palette, 0, to, 0, 15)
            colorT0 = SystemClock.uptimeMillis()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        readCorners(rootWindowInsets)
    }

    override fun onDetachedFromWindow() {
        looping = false
        running = false
        removeCallbacks(finishRunnable)
        removeCallbacks(restartRunnable)
        super.onDetachedFromWindow()
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        readCorners(insets)
        return super.onApplyWindowInsets(insets)
    }

    private fun readCorners(insets: WindowInsets?) {
        if (insets == null) return
        var best = 0
        val positions = intArrayOf(
            RoundedCorner.POSITION_TOP_LEFT,
            RoundedCorner.POSITION_TOP_RIGHT,
            RoundedCorner.POSITION_BOTTOM_LEFT,
            RoundedCorner.POSITION_BOTTOM_RIGHT,
        )
        for (p in positions) {
            val c = insets.getRoundedCorner(p)
            if (c != null && c.radius > best) best = c.radius
        }
        if (best > 0) cornerPx = best.toFloat()
    }

    private val restartRunnable = Runnable {
        if (looping && isAttachedToWindow) trigger(lastPalette, cfg)
    }

    override fun onDraw(canvas: Canvas) {
        if (!running) return
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame).coerceIn(0L, 64L) / 1000f
        lastFrame = now

        // envelope: target -> stage1 -> level
        val target = if (now < holdUntil) 1f else 0f
        val tau1 = if (target > stage1) 0.16f else 0.30f
        stage1 += (target - stage1) * (1f - exp(-dt / tau1))
        level += (stage1 - level) * (1f - exp(-dt / 0.12f))

        if (target == 0f && level < 0.004f) {
            running = false
            if (looping) {
                postDelayed(restartRunnable, 900L)
            } else {
                post(finishRunnable)
            }
            return
        }

        // colour blend towards the latest palette
        val ct = ((now - colorT0) / 450f).coerceIn(0f, 1f)
        val e = ct * ct * (3f - 2f * ct)
        for (i in 0 until 15) cur[i] = from[i] + (to[i] - from[i]) * e

        // travelling highlight: one lap, eased, strongest mid-lap
        val sp = ((now - sweepStart) / SWEEP_MS).coerceIn(0f, 1f)
        val q = -2f * sp + 2f
        val sweep = if (sp < 0.5f) 4f * sp * sp * sp else 1f - q * q * q / 2f
        val sweepAmt = if (sp >= 1f) 0f else sqrt(sin(PI * sp).toFloat().coerceAtLeast(0f))

        val radius = when {
            fixedCornerPx >= 0f -> fixedCornerPx
            cornerPx > 0f -> cornerPx
            else -> min(w, h) * 0.08f
        }

        val t = ((now - timeBase) % 600_000L) / 1000f

        rt.setFloatUniform("uRes", w, h)
        rt.setFloatUniform("uTime", t)
        rt.setFloatUniform("uLevel", level.coerceIn(0f, 1f))
        rt.setFloatUniform("uSweep", sweep)
        rt.setFloatUniform("uSweepAmt", sweepAmt)
        rt.setFloatUniform("uDepth", cfg.depthDp * density)
        rt.setFloatUniform("uRadius", radius)
        rt.setFloatUniform("uDot", cfg.dot)
        rt.setFloatUniform("uCell", cfg.cellDp * density)
        rt.setFloatUniform("uWave", cfg.wave)
        rt.setFloatUniform("uSpeed", cfg.speed)
        rt.setFloatUniform("uGain", cfg.gain)
        rt.setFloatUniform("uC0", cur[0], cur[1], cur[2])
        rt.setFloatUniform("uC1", cur[3], cur[4], cur[5])
        rt.setFloatUniform("uC2", cur[6], cur[7], cur[8])
        rt.setFloatUniform("uC3", cur[9], cur[10], cur[11])
        rt.setFloatUniform("uC4", cur[12], cur[13], cur[14])

        canvas.drawRect(0f, 0f, w, h, paint)
        postInvalidateOnAnimation()
    }

    companion object {
        private const val INTRO_MS = 450L
        private const val SWEEP_MS = 1700f
    }
}

/** Loads the AGSL source and can check, on the actual device, that it compiles. */
object GlowShader {
    @Volatile
    private var source: String? = null

    /** Null while everything is fine, otherwise the shader compiler's message. Observable by the UI. */
    var error: String? by mutableStateOf(null)

    fun source(context: Context): String {
        source?.let { return it }
        val text = context.resources.openRawResource(R.raw.glow).bufferedReader().use { it.readText() }
        source = text
        return text
    }

    fun check(context: Context) {
        error = try {
            RuntimeShader(source(context))
            null
        } catch (e: Exception) {
            e.message ?: e.toString()
        }
    }
}
