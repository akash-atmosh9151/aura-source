package dev.aura.glow

/** A snapshot of everything the shader needs besides colours, derived from the user's settings. */
data class GlowConfig(
    val dot: Float,        // 0 smooth .. 1 dot matrix
    val gain: Float,       // brightness
    val depthDp: Float,    // how far the glow reaches in
    val wave: Float,       // wave amplitude
    val speed: Float,      // wave speed
    val holdMs: Long,      // how long it stays at full strength
    val haptic: Boolean,
    val cellDp: Float = 3.4f,
) {
    companion object {
        fun fromStore(): GlowConfig {
            val dot = when (AuraStore.style) {
                Styles.NOTHING -> 1f
                Styles.HYBRID -> 0.55f
                else -> 0f
            }
            return GlowConfig(
                dot = dot,
                gain = 0.45f + 0.9f * AuraStore.intensity,
                depthDp = 38f + 100f * AuraStore.depth,
                wave = 0.35f + 1.25f * AuraStore.wave,
                speed = 0.45f + 1.4f * AuraStore.speed,
                holdMs = (700f + 4300f * AuraStore.duration).toLong(),
                haptic = AuraStore.haptic,
            )
        }
    }
}
