package dev.aura.glow

import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String)

/** What the colour sheet is editing: one app, or (pkg == null) the default for all other apps. */
data class SheetTarget(val pkg: String?, val label: String)

private val spectrumBrush: Brush = Brush.sweepGradient(
    listOf(
        Color(0xFFFF4FA3),
        Color(0xFFFF8A3D),
        Color(0xFF8B5CFF),
        Color(0xFF3D8BFF),
        Color(0xFF2DE2E6),
        Color(0xFFFF4FA3),
    ),
)

@Composable
fun rememberInstalledApps(): List<AppInfo> {
    val ctx = LocalContext.current
    val apps by produceState(initialValue = emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
                .map { info -> AppInfo(info.loadLabel(pm).toString(), info.activityInfo.packageName) }
                .filter { app -> app.pkg != ctx.packageName }
                .distinctBy { app -> app.pkg }
                .sortedBy { app -> app.label.lowercase() }
        }
    }
    return apps
}

private val iconCache = HashMap<String, ImageBitmap>()

@Composable
fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = iconCache[pkg], key1 = pkg) {
        if (value == null) {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            }
            if (loaded != null) iconCache[pkg] = loaded
            value = loaded
        }
    }
    val shape = RoundedCornerShape(size * 0.28f)
    val b = bitmap
    if (b != null) {
        Image(
            bitmap = b,
            contentDescription = null,
            modifier = modifier.size(size).clip(shape),
        )
    } else {
        Box(modifier.size(size).clip(shape).background(NC.Surface2))
    }
}

/** A colour chip: solid, spectrum, or an empty ring when [color] is null. */
@Composable
fun ColorDot(color: Int?, size: Dp, selected: Boolean = false, modifier: Modifier = Modifier) {
    val ring = if (selected) NC.White else Color.Transparent
    val fill: Brush? = if (color == null) {
        null
    } else if (color == Palette.SPECTRUM) {
        spectrumBrush
    } else {
        SolidColor(Color(color))
    }
    Box(modifier.size(size).border(2.dp, ring, CircleShape).padding(if (selected) 4.dp else 0.dp)) {
        if (fill != null) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(fill))
        } else {
            Box(Modifier.fillMaxSize().border(1.5.dp, NC.Faint, CircleShape))
        }
    }
}

@Composable
fun AppRow(app: AppInfo, onClick: () -> Unit) {
    val color = AuraStore.appColors[app.pkg]
    val on = AuraStore.isAppEnabled(app.pkg)
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().tap(onClick).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIcon(app.pkg, 40.dp, Modifier.alpha(if (on) 1f else 0.4f))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f).padding(end = 10.dp)) {
                Body(app.label, size = 15.sp, maxLines = 1, color = if (on) NC.White else NC.Dim)
                Label(
                    if (!on) "off" else if (color != null) "custom color" else "default color",
                    size = 10.sp,
                )
            }
            ColorDot(if (on) (color ?: AuraStore.defaultColor) else null, 26.dp)
        }
        Hairline()
    }
}

/** Horizontal gradient strip with a round thumb. */
@Composable
private fun ColorStrip(
    brush: Brush,
    fraction: Float,
    thumb: Color,
    onFraction: (Float) -> Unit,
    onEnd: () -> Unit,
) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(34.dp)
            .scrubbable(onEnd = onEnd, onFraction = onFraction),
    ) {
        val trackH = 14.dp.toPx()
        drawRoundRect(
            brush = brush,
            topLeft = Offset(0f, (size.height - trackH) / 2f),
            size = Size(size.width, trackH),
            cornerRadius = CornerRadius(trackH / 2f, trackH / 2f),
        )
        val r = 12.dp.toPx()
        val x = r + (size.width - 2f * r) * fraction.coerceIn(0f, 1f)
        drawCircle(Color.White, radius = r, center = Offset(x, size.height / 2f))
        drawCircle(thumb, radius = r - 3.dp.toPx(), center = Offset(x, size.height / 2f))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorSheet(target: SheetTarget, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val pkg = target.pkg
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val current: Int? = if (pkg == null) AuraStore.defaultColor else AuraStore.appColors[pkg]
    val startHsv = remember(pkg) {
        val arr = FloatArray(3)
        if (current != null && current != Palette.SPECTRUM) {
            android.graphics.Color.colorToHSV(current, arr)
        } else {
            arr[0] = 0f
            arr[1] = 1f
            arr[2] = 1f
        }
        arr
    }
    var hue by remember(pkg) { mutableFloatStateOf(startHsv[0] / 360f) }
    var sat by remember(pkg) { mutableFloatStateOf(startHsv[1]) }
    var warned by remember { mutableStateOf(false) }

    fun play(color: Int, restartSweep: Boolean) {
        val ok = GlowOverlay.show(ctx, color, GlowConfig.fromStore(), restartSweep)
        if (!ok && !warned) {
            warned = true
            Toast.makeText(ctx, "Allow \"Display over other apps\" to preview", Toast.LENGTH_SHORT).show()
        }
    }

    fun applyColor(color: Int, restartSweep: Boolean) {
        if (pkg == null) AuraStore.defaultColor = color else AuraStore.setAppColor(pkg, color)
        play(color, restartSweep)
    }

    fun customColor(): Int =
        Color.hsv((hue * 360f).coerceIn(0f, 359.9f), sat.coerceIn(0f, 1f), 1f).toArgb()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = NC.Surface,
        contentColor = NC.White,
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 12.dp, bottom = 6.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(NC.Faint),
            )
        },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 22.dp)
                .padding(bottom = 24.dp),
        ) {
            // header
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (pkg != null) {
                    AppIcon(pkg, 44.dp)
                } else {
                    ColorDot(AuraStore.defaultColor, 44.dp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Body(target.label, size = 18.sp, maxLines = 1)
                    Label("Glow color", size = 10.sp)
                }
            }

            if (pkg != null) {
                Spacer(Modifier.height(6.dp))
                ToggleRow(
                    title = "Glow for this app",
                    sub = "Turn off to keep this app silent",
                    checked = AuraStore.isAppEnabled(pkg),
                    onChange = { AuraStore.setAppEnabled(pkg, it) },
                )
            }

            Spacer(Modifier.height(10.dp))
            Hairline()
            Spacer(Modifier.height(16.dp))
            Label("Presets", color = NC.White, size = 11.sp, weight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            val all = listOf(Palette.SPECTRUM) + Palette.swatches
            for (rowItems in all.chunked(7)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (c in rowItems) {
                        ColorDot(
                            color = c,
                            size = 40.dp,
                            selected = current == c,
                            modifier = Modifier.tap { applyColor(c, true) },
                        )
                    }
                    // keep the last row aligned with the grid
                    repeat(7 - rowItems.size) { Spacer(Modifier.size(40.dp)) }
                }
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(10.dp))
            Label("Custom", color = NC.White, size = 11.sp, weight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Label("Hue", size = 10.sp)
            val hueBrush = remember {
                Brush.horizontalGradient(
                    listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { h -> Color.hsv(h % 360f, 1f, 1f) },
                )
            }
            ColorStrip(
                brush = hueBrush,
                fraction = hue,
                thumb = Color.hsv((hue * 360f).coerceIn(0f, 359.9f), 1f, 1f),
                onFraction = { f ->
                    hue = f
                    applyColor(customColor(), false)
                },
                onEnd = { applyColor(customColor(), true) },
            )
            Spacer(Modifier.height(6.dp))
            Label("Saturation", size = 10.sp)
            val satBrush = remember(hue) {
                Brush.horizontalGradient(
                    listOf(Color.White, Color.hsv((hue * 360f).coerceIn(0f, 359.9f), 1f, 1f)),
                )
            }
            ColorStrip(
                brush = satBrush,
                fraction = sat,
                thumb = Color(customColor()),
                onFraction = { f ->
                    sat = f
                    applyColor(customColor(), false)
                },
                onEnd = { applyColor(customColor(), true) },
            )

            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(
                    text = "Preview",
                    filled = true,
                    modifier = Modifier.weight(1f),
                    onClick = { play(if (pkg == null) AuraStore.defaultColor else AuraStore.colorFor(pkg), true) },
                )
                PillButton(
                    text = "Reset",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (pkg == null) {
                            AuraStore.defaultColor = 0xFFD71921.toInt()
                        } else {
                            AuraStore.setAppColor(pkg, null)
                            AuraStore.setAppEnabled(pkg, true)
                        }
                    },
                )
            }
        }
    }
}
