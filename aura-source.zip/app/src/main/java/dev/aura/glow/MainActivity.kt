package dev.aura.glow

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.app.NotificationManagerCompat

class MainActivity : ComponentActivity() {

    // bumped on every resume so the permission rows re-check themselves after a trip to Settings
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        GlowShader.check(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AuraScreen(
                    tick = tick.intValue,
                    onGrantListener = { openListenerSettings() },
                    onGrantOverlay = { openOverlaySettings() },
                    onGrantBattery = { openBatterySettings() },
                    onAppInfo = { openAppInfo() },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue += 1
        // after an APK update the system doesn't always reconnect the listener on its own
        try {
            if (NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)) {
                NotificationListenerService.requestRebind(ComponentName(this, AuraListener::class.java))
            }
        } catch (e: Exception) {
            // best effort
        }
    }

    private fun openListenerSettings() {
        val component = ComponentName(this, AuraListener::class.java).flattenToString()
        try {
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, component),
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e2: Exception) {
                openAppInfo()
            }
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            openAppInfo()
        }
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppInfo()
            }
        }
    }

    private fun openAppInfo() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            // nothing else to try
        }
    }
}
