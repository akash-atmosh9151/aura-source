package dev.aura.glow

import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/** Design tokens: black, white, one red. */
object NC {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF0D0D0D)
    val Surface2 = Color(0xFF161616)
    val Line = Color(0xFF262626)
    val White = Color(0xFFFFFFFF)
    val Dim = Color(0xFF8E8E8E)
    val Faint = Color(0xFF3A3A3A)
    val Red = Color(0xFFD71921)
}

/** Small monospaced all-caps label. */
@Composable
fun Label(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = NC.Dim,
    size: TextUnit = 11.sp,
    spacing: TextUnit = 1.4.sp,
    weight: FontWeight = FontWeight.Normal,
    align: TextAlign = TextAlign.Unspecified,
    maxLines: Int = 1,
) {
    BasicText(
        text = text.uppercase(),
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size,
            fontFamily = FontFamily.Monospace,
            letterSpacing = spacing,
            fontWeight = weight,
            textAlign = align,
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

/** Regular sans text. */
@Composable
fun Body(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = NC.White,
    size: TextUnit = 16.sp,
    weight: FontWeight = FontWeight.Medium,
    maxLines: Int = Int.MAX_VALUE,
    mono: Boolean = false,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size,
            fontWeight = weight,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
            lineHeight = size * 1.3f,
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
