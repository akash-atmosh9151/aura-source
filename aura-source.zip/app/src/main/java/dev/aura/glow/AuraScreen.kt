package dev.aura.glow

import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun AuraScreen(
    tick: Int,
    onGrantListener: () -> Unit,
    onGrantOverlay: () -> Unit,
    onGrantBattery: () -> Unit,
    onAppInfo: () -> Unit,
) {
    val ctx = LocalContext.current

    // re-evaluated whenever the activity resumes (tick changes), e.g. after returning from Settings
    val listenerOk = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val ready = listenerOk && overlayOk && AuraStore.enabled

    val apps = rememberInstalledApps()
    var query by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf<SheetTarget?>(null) }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { app -> app.label.contains(query.trim(), ignoreCase = true) }
    }

    val previewOnScreen: () -> Unit = {
        val ok = GlowOverlay.show(ctx, AuraStore.defaultColor, GlowConfig.fromStore())
        if (!ok) {
            Toast.makeText(ctx, "Allow \"Display over other apps\" first", Toast.LENGTH_SHORT).show()
        }
    }

    val bars = WindowInsets.systemBars.asPaddingValues()

    Box(Modifier.fillMaxSize().background(NC.Black)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = bars.calculateTopPadding() + 16.dp,
                bottom = bars.calculateBottomPadding() + 40.dp,
            ),
        ) {
            item {
                Column(Modifier.padding(bottom = 20.dp)) {
                    Header(ready)
                }
            }

            val shaderError = GlowShader.error
            if (shaderError != null) {
                item {
                    Column(Modifier.padding(bottom = 16.dp)) {
                        NCard(Modifier.border(1.dp, NC.Red, RoundedCornerShape(26.dp))) {
                            Label("Glow shader failed on this device", color = NC.Red, size = 11.sp, weight = FontWeight.Bold, maxLines = 3)
                            Spacer(Modifier.height(8.dp))
                            Body(shaderError, size = 11.sp, color = NC.Dim, weight = FontWeight.Normal, mono = true)
                        }
                    }
                }
            }

            item {
                Column(Modifier.padding(bottom = 20.dp)) {
                    Hero(showGlow = shaderError == null, onPreview = previewOnScreen)
                }
            }

            item {
                Column(Modifier.padding(bottom = 16.dp)) {
                    SetupCard(
                        listenerOk = listenerOk,
                        overlayOk = overlayOk,
                        batteryOk = batteryOk,
                        onListener = onGrantListener,
                        onOverlay = onGrantOverlay,
                        onBattery = onGrantBattery,
                        onAppInfo = onAppInfo,
                    )
                }
            }

            item {
                Column(Modifier.padding(bottom = 16.dp)) {
                    LookCard(onPreview = previewOnScreen)
                }
            }

            item {
                Column(Modifier.padding(bottom = 16.dp)) {
                    BehaviourCard()
                }
            }

            item {
                Column(Modifier.padding(bottom = 16.dp)) {
                    NCard {
                        SectionTitle("04  Colors", "per app")
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .tap { sheet = SheetTarget(null, "All other apps") }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ColorDot(AuraStore.defaultColor, 36.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f).padding(end = 10.dp)) {
                                Body("Default color", size = 15.sp)
                                Body(
                                    "Used by every app without its own color",
                                    size = 12.sp,
                                    color = NC.Dim,
                                    weight = FontWeight.Normal,
                                )
                            }
                            Label("Edit", color = NC.White, size = 10.sp)
                        }
                    }
                }
            }

            item {
                Column(Modifier.padding(top = 8.dp, bottom = 12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Label("Apps", color = NC.White, size = 11.sp, weight = FontWeight.Bold, spacing = 1.8.sp)
                        Spacer(Modifier.weight(1f))
                        Label("${filtered.size} shown", size = 10.sp)
                    }
                    SearchField(query) { query = it }
                }
            }

            items(items = filtered, key = { app -> app.pkg }) { app ->
                AppRow(app) { sheet = SheetTarget(app.pkg, app.label) }
            }

            if (apps.isEmpty()) {
                item { Label("Loading apps", size = 10.sp, modifier = Modifier.padding(vertical = 20.dp)) }
            } else if (filtered.isEmpty()) {
                item { Label("No apps match", size = 10.sp, modifier = Modifier.padding(vertical = 20.dp)) }
            }

            item {
                Box(Modifier.fillMaxWidth().padding(top = 28.dp), contentAlignment = Alignment.Center) {
                    Label("Aura 1.0", size = 10.sp, color = NC.Faint)
                }
            }
        }

        val target = sheet
        if (target != null) {
            ColorSheet(target) { sheet = null }
        }
    }
}

@Composable
private fun Header(ready: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            DotText("AURA", 6.dp, NC.White, shimmer = true)
            Spacer(Modifier.height(12.dp))
            Label("Notification edge glow", size = 11.sp)
        }
        Row(
            Modifier
                .clip(CircleShape)
                .border(1.dp, NC.Line, CircleShape)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (ready) NC.White else NC.Red),
            )
            Spacer(Modifier.width(8.dp))
            Label(if (ready) "Live" else "Setup", color = if (ready) NC.White else NC.Red, size = 10.sp, weight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Hero(showGlow: Boolean, onPreview: () -> Unit) {
    val density = LocalDensity.current
    var glowRef by remember { mutableStateOf<GlowView?>(null) }
    val now = remember { LocalDateTime.now() }
    val clock = remember { now.format(DateTimeFormatter.ofPattern("HH:mm")) }
    val date = remember { now.format(DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH)) }
    val phoneShape = RoundedCornerShape(38.dp)

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(width = 214.dp, height = 430.dp)
                .clip(phoneShape)
                .background(Color.Black)
                .border(1.5.dp, NC.Line, phoneShape)
                .pointerInput(Unit) {
                    detectTapGestures { glowRef?.replay() }
                },
        ) {
            Column(
                Modifier.fillMaxSize().padding(top = 78.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                DotText(clock, 5.dp, NC.White)
                Spacer(Modifier.height(14.dp))
                Label(date, size = 10.sp)
            }

            // a stand-in notification card
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 58.dp)
                    .width(176.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(NC.Surface2)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(NC.Faint))
                Spacer(Modifier.width(10.dp))
                Column {
                    Box(Modifier.width(78.dp).height(6.dp).clip(CircleShape).background(NC.Dim))
                    Spacer(Modifier.height(7.dp))
                    Box(Modifier.width(54.dp).height(6.dp).clip(CircleShape).background(NC.Faint))
                }
            }

            if (showGlow) {
                AndroidView(
                    factory = { c ->
                        val v = GlowView(c)
                        v.fixedCornerPx = with(density) { 38.dp.toPx() }
                        glowRef = v
                        v
                    },
                    modifier = Modifier.fillMaxSize(),
                    update = { v -> v.runLoop(Palette.build(AuraStore.defaultColor), GlowConfig.fromStore()) },
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Label("Tap the phone to replay", size = 10.sp, color = NC.Faint)
        Spacer(Modifier.height(14.dp))
        PillButton("Preview on screen", onClick = onPreview, filled = true)
    }
}

@Composable
private fun PermRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (ok) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(NC.White))
        } else {
            Box(Modifier.size(12.dp).border(1.5.dp, NC.Red, CircleShape))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Body(title, size = 15.sp)
            Body(sub, size = 12.sp, color = NC.Dim, weight = FontWeight.Normal)
        }
        if (ok) {
            Label("On", size = 10.sp)
        } else {
            PillButton("Grant", onClick = onClick, filled = true)
        }
    }
}

@Composable
private fun SetupCard(
    listenerOk: Boolean,
    overlayOk: Boolean,
    batteryOk: Boolean,
    onListener: () -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onAppInfo: () -> Unit,
) {
    NCard {
        SectionTitle("01  Setup", "3 permissions")
        PermRow("Notification access", "So Aura knows when something arrives", listenerOk, onListener)
        if (!listenerOk) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NC.Surface2)
                    .padding(14.dp),
            ) {
                Body(
                    "If the switch is greyed out, Android is restricting sideloaded apps: " +
                        "open App info, tap the three dots at the top right, choose \"Allow restricted settings\", then grant again.",
                    size = 12.sp,
                    color = NC.Dim,
                    weight = FontWeight.Normal,
                )
                Spacer(Modifier.height(10.dp))
                PillButton("Open app info", onClick = onAppInfo)
            }
        }
        Hairline()
        PermRow("Display over other apps", "Needed to draw the glow on top", overlayOk, onOverlay)
        Hairline()
        PermRow("Unrestricted battery", "Keeps Aura alive in the background", batteryOk, onBattery)
        Hairline()
        ToggleRow(
            title = "Glow on notifications",
            sub = "Master switch",
            checked = AuraStore.enabled,
            onChange = { AuraStore.enabled = it },
        )
    }
}

@Composable
private fun LookCard(onPreview: () -> Unit) {
    val blurb = when (AuraStore.style) {
        Styles.NOTHING -> "Dot-matrix light, in the spirit of the glyph interface. The default."
        Styles.HYBRID -> "Soft light with a dot-matrix texture running through it."
        else -> "Pure liquid light that flows around the screen."
    }
    NCard {
        SectionTitle("02  Look", "live preview above")
        Segmented(
            options = listOf("Nothing", "Hybrid", "Fluid"),
            selected = AuraStore.style,
            onSelect = {
                AuraStore.style = it
                onPreview()
            },
        )
        Spacer(Modifier.height(10.dp))
        Body(blurb, size = 12.sp, color = NC.Dim, weight = FontWeight.Normal)
        SliderRow("Intensity", AuraStore.intensity, { AuraStore.intensity = it }, onPreview)
        SliderRow("Depth", AuraStore.depth, { AuraStore.depth = it }, onPreview)
        SliderRow("Wave", AuraStore.wave, { AuraStore.wave = it }, onPreview)
        SliderRow("Speed", AuraStore.speed, { AuraStore.speed = it }, onPreview)
        SliderRow("Duration", AuraStore.duration, { AuraStore.duration = it }, onPreview)
    }
}

@Composable
private fun BehaviourCard() {
    NCard {
        SectionTitle("03  Behaviour")
        ToggleRow(
            "Respect Do Not Disturb",
            "Stay dark for notifications that are silenced",
            AuraStore.respectDnd,
        ) { AuraStore.respectDnd = it }
        Hairline()
        ToggleRow(
            "Skip ongoing and progress",
            "Music players, downloads, navigation",
            AuraStore.skipOngoing,
        ) { AuraStore.skipOngoing = it }
        Hairline()
        ToggleRow(
            "Skip silent notifications",
            "Only glow for ones that alert",
            AuraStore.skipSilent,
        ) { AuraStore.skipSilent = it }
        Hairline()
        ToggleRow(
            "Haptic tick",
            "A light tap as the glow appears",
            AuraStore.haptic,
        ) { AuraStore.haptic = it }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(CircleShape)
            .background(NC.Surface2)
            .border(1.dp, NC.Line, CircleShape)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (value.isEmpty()) {
            Label("Search apps", size = 12.sp, color = NC.Faint)
        }
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = NC.White, fontSize = 15.sp),
            cursorBrush = SolidColor(NC.Red),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
