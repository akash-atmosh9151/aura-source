package dev.aura.glow

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import kotlin.reflect.KProperty

object Styles {
    const val NOTHING = 0
    const val HYBRID = 1
    const val FLUID = 2
}

// Backing SharedPreferences, shared by the delegates below.
private var prefs: SharedPreferences? = null

private class BoolPref(private val key: String, private val def: Boolean) {
    private val state = mutableStateOf(def)
    fun load(sp: SharedPreferences) {
        state.value = sp.getBoolean(key, def)
    }

    operator fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = state.value
    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        state.value = value
        prefs?.edit()?.putBoolean(key, value)?.apply()
    }
}

private class IntPref(private val key: String, private val def: Int) {
    private val state = mutableStateOf(def)
    fun load(sp: SharedPreferences) {
        state.value = sp.getInt(key, def)
    }

    operator fun getValue(thisRef: Any?, property: KProperty<*>): Int = state.value
    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        state.value = value
        prefs?.edit()?.putInt(key, value)?.apply()
    }
}

private class FloatPref(private val key: String, private val def: Float) {
    private val state = mutableStateOf(def)
    fun load(sp: SharedPreferences) {
        state.value = sp.getFloat(key, def)
    }

    operator fun getValue(thisRef: Any?, property: KProperty<*>): Float = state.value
    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
        state.value = value
        prefs?.edit()?.putFloat(key, value)?.apply()
    }
}

/**
 * All user settings. Backed by observable Compose state, so the UI updates live,
 * and by SharedPreferences, so the notification service sees the same values.
 */
object AuraStore {
    private val enabledP = BoolPref("enabled", true)
    private val styleP = IntPref("style", Styles.NOTHING)
    private val defaultColorP = IntPref("defaultColor", 0xFFD71921.toInt()) // Nothing red
    private val intensityP = FloatPref("intensity", 0.60f)
    private val depthP = FloatPref("depth", 0.25f)
    private val waveP = FloatPref("wave", 0.50f)
    private val speedP = FloatPref("speed", 0.50f)
    private val durationP = FloatPref("duration", 0.25f)
    private val respectDndP = BoolPref("respectDnd", true)
    private val skipOngoingP = BoolPref("skipOngoing", true)
    private val skipSilentP = BoolPref("skipSilent", false)
    private val hapticP = BoolPref("haptic", false)

    var enabled by enabledP
    var style by styleP
    var defaultColor by defaultColorP
    var intensity by intensityP
    var depth by depthP
    var wave by waveP
    var speed by speedP
    var duration by durationP
    var respectDnd by respectDndP
    var skipOngoing by skipOngoingP
    var skipSilent by skipSilentP
    var haptic by hapticP

    /** Per-app colour overrides (package name -> ARGB, or Palette.SPECTRUM). */
    val appColors = mutableStateMapOf<String, Int>()

    /** Apps the user switched off. A key being present means "off". */
    val disabledApps = mutableStateMapOf<String, Boolean>()

    fun init(context: Context) {
        val sp = context.applicationContext.getSharedPreferences("aura", Context.MODE_PRIVATE)
        prefs = sp
        enabledP.load(sp)
        styleP.load(sp)
        defaultColorP.load(sp)
        intensityP.load(sp)
        depthP.load(sp)
        waveP.load(sp)
        speedP.load(sp)
        durationP.load(sp)
        respectDndP.load(sp)
        skipOngoingP.load(sp)
        skipSilentP.load(sp)
        hapticP.load(sp)

        appColors.clear()
        for (line in (sp.getString("appColors", "") ?: "").split("\n")) {
            val i = line.lastIndexOf(':')
            if (i > 0) {
                val c = line.substring(i + 1).toIntOrNull()
                if (c != null) appColors[line.substring(0, i)] = c
            }
        }
        disabledApps.clear()
        for (line in (sp.getString("disabledApps", "") ?: "").split("\n")) {
            if (line.isNotBlank()) disabledApps[line] = true
        }
    }

    private fun persistMaps() {
        val colors = appColors.entries.joinToString("\n") { e -> "${e.key}:${e.value}" }
        val off = disabledApps.keys.joinToString("\n")
        prefs?.edit()
            ?.putString("appColors", colors)
            ?.putString("disabledApps", off)
            ?.apply()
    }

    fun setAppColor(pkg: String, color: Int?) {
        if (color == null) appColors.remove(pkg) else appColors[pkg] = color
        persistMaps()
    }

    fun setAppEnabled(pkg: String, on: Boolean) {
        if (on) disabledApps.remove(pkg) else disabledApps[pkg] = true
        persistMaps()
    }

    fun isAppEnabled(pkg: String): Boolean = !disabledApps.containsKey(pkg)

    fun colorFor(pkg: String): Int = appColors[pkg] ?: defaultColor
}
