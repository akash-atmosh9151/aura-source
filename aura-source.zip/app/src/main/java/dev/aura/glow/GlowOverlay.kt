package dev.aura.glow

import android.content.Context
import android.graphics.PixelFormat
import android.os.VibrationEffect
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/** Owns the single full-screen, click-through overlay window that the glow is drawn into. */
object GlowOverlay {
    private var view: GlowView? = null
    private var manager: WindowManager? = null

    /**
     * Plays the glow. Must be called on the main thread.
     * Returns false if the "display over other apps" permission is missing or the window can't be added.
     */
    fun show(context: Context, color: Int, config: GlowConfig, restartSweep: Boolean = true): Boolean {
        val app = context.applicationContext
        if (!Settings.canDrawOverlays(app)) return false

        val palette = Palette.build(color)

        val existing = view
        if (existing != null && existing.isAttachedToWindow) {
            existing.trigger(palette, config, restartSweep)
            return true
        }

        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bounds = wm.maximumWindowMetrics.bounds

        val params = WindowManager.LayoutParams(
            bounds.width(),
            bounds.height(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        params.title = "AuraGlow"

        val glow = try {
            GlowView(app)
        } catch (e: Exception) {
            // most likely the shader failed to compile on this device; the app shows the message
            GlowShader.check(app)
            return false
        }
        try {
            wm.addView(glow, params)
        } catch (e: Exception) {
            return false
        }
        view = glow
        manager = wm
        glow.onFinished = { remove() }
        glow.trigger(palette, config)
        return true
    }

    private fun remove() {
        val v = view ?: return
        try {
            manager?.removeViewImmediate(v)
        } catch (e: Exception) {
            // already gone
        }
        view = null
    }

    fun tick(context: Context) {
        try {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } catch (e: Exception) {
            // no vibrator, or not allowed
        }
    }
}
