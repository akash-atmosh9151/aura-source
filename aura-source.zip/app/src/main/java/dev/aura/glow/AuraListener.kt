package dev.aura.glow

import android.app.Notification
import android.app.NotificationManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.StatusBarNotification

/** Receives every notification the system posts and lights the screen edge for the ones that qualify. */
class AuraListener : NotificationListenerService() {

    private val main = Handler(Looper.getMainLooper())
    private val lastShown = HashMap<String, Long>()
    private var lastAny = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Exception) {
            // never let a bad notification take the listener down
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!AuraStore.enabled) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        if (!AuraStore.isAppEnabled(pkg)) return

        val n = sbn.notification ?: return
        val flags = n.flags

        // the summary of a bundle would double-fire next to the individual messages
        if ((flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        if (AuraStore.skipOngoing) {
            if ((flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if ((flags and Notification.FLAG_FOREGROUND_SERVICE) != 0) return
            val extras = n.extras
            if (extras != null) {
                if (extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0) return
                if (extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return
            }
        }

        val key = sbn.key
        try {
            val ranking = Ranking()
            if (currentRanking.getRanking(key, ranking)) {
                if (ranking.importance <= NotificationManager.IMPORTANCE_MIN) return
                if (AuraStore.respectDnd && !ranking.matchesInterruptionFilter()) return
                if (AuraStore.skipSilent && ranking.importance < NotificationManager.IMPORTANCE_DEFAULT) return
            }
        } catch (e: Exception) {
            // ranking unavailable: fall through and show it
        }

        val now = SystemClock.uptimeMillis()
        val last = lastShown[key]
        if (last != null) {
            // an update to something we already lit up for
            if ((flags and Notification.FLAG_ONLY_ALERT_ONCE) != 0) return
            if (now - last < 2500L) return
        }
        if (now - lastAny < 300L) return // a burst of different notifications: one glow is enough
        lastShown[key] = now
        lastAny = now
        if (lastShown.size > 300) {
            val cutoff = now - 10 * 60 * 1000L
            lastShown.entries.removeAll { entry -> entry.value < cutoff }
        }

        val color = AuraStore.colorFor(pkg)
        val config = GlowConfig.fromStore()
        main.post {
            GlowOverlay.show(applicationContext, color, config)
            if (config.haptic) GlowOverlay.tick(applicationContext)
        }
    }
}
