package dev.aura.glow

import android.graphics.Color
import androidx.core.graphics.ColorUtils

/** Turns one chosen colour into the five-colour ribbon the shader flows through. */
object Palette {
    /** Sentinel for the multicolour option. Alpha is 0, so it can never be a real colour. */
    const val SPECTRUM = 1

    private fun rgb(hex: Int): Int = hex or (0xFF shl 24)

    private val spectrum = intArrayOf(
        rgb(0xFF4FA3), // pink
        rgb(0xFF8A3D), // orange
        rgb(0x8B5CFF), // violet
        rgb(0x3D8BFF), // blue
        rgb(0x2DE2E6), // cyan
    )

    /** Swatches shown in the picker (Spectrum is added in front by the UI). */
    val swatches: List<Int> = listOf(
        rgb(0xD71921), // red
        rgb(0xFF6A00), // orange
        rgb(0xFFB300), // amber
        rgb(0xC6F432), // lime
        rgb(0x30D158), // green
        rgb(0x2DE2B0), // mint
        rgb(0x20C7FF), // cyan
        rgb(0x2F6BFF), // blue
        rgb(0x5B4BFF), // indigo
        rgb(0x9B5CFF), // violet
        rgb(0xE0197A), // magenta
        rgb(0xFF5FA2), // pink
        rgb(0xFFFFFF), // white
    )

    /** 15 floats: five colours, r g b each in 0..1. */
    fun build(color: Int): FloatArray {
        val cols = if (color == SPECTRUM) spectrum else derive(color)
        val out = FloatArray(15)
        for (i in 0 until 5) {
            out[i * 3] = Color.red(cols[i]) / 255f
            out[i * 3 + 1] = Color.green(cols[i]) / 255f
            out[i * 3 + 2] = Color.blue(cols[i]) / 255f
        }
        return out
    }

    private fun derive(base: Int): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(base, hsv)

        fun shift(dh: Float, ds: Float): Int {
            val h = (hsv[0] + dh + 360f) % 360f
            val s = (hsv[1] * ds).coerceIn(0f, 1f)
            return Color.HSVToColor(floatArrayOf(h, s, hsv[2]))
        }

        val solid = base or (0xFF shl 24)
        return intArrayOf(
            solid,
            shift(28f, 0.95f),
            ColorUtils.blendARGB(solid, Color.WHITE, 0.45f),
            shift(-26f, 0.95f),
            shift(10f, 1.0f),
        )
    }
}
