package dev.aura.glow

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** A tiny 5x7 dot-matrix font, drawn as circles. Seven rows per glyph, joined with "/". */
private val GLYPHS: Map<Char, String> = mapOf(
    ' ' to "...../...../...../...../...../...../.....",
    'A' to ".###./#...#/#...#/#####/#...#/#...#/#...#",
    'B' to "####./#...#/#...#/####./#...#/#...#/####.",
    'C' to ".###./#...#/#..../#..../#..../#...#/.###.",
    'D' to "####./#...#/#...#/#...#/#...#/#...#/####.",
    'E' to "#####/#..../#..../####./#..../#..../#####",
    'F' to "#####/#..../#..../####./#..../#..../#....",
    'G' to ".###./#...#/#..../#.###/#...#/#...#/.###.",
    'H' to "#...#/#...#/#...#/#####/#...#/#...#/#...#",
    'I' to ".###./..#../..#../..#../..#../..#../.###.",
    'J' to "..###/...#./...#./...#./...#./#..#./.##..",
    'K' to "#...#/#..#./#.#../##.../#.#../#..#./#...#",
    'L' to "#..../#..../#..../#..../#..../#..../#####",
    'M' to "#...#/##.##/#.#.#/#.#.#/#...#/#...#/#...#",
    'N' to "#...#/##..#/#.#.#/#..##/#...#/#...#/#...#",
    'O' to ".###./#...#/#...#/#...#/#...#/#...#/.###.",
    'P' to "####./#...#/#...#/####./#..../#..../#....",
    'Q' to ".###./#...#/#...#/#...#/#.#.#/#..#./.##.#",
    'R' to "####./#...#/#...#/####./#.#../#..#./#...#",
    'S' to ".####/#..../#..../.###./....#/....#/####.",
    'T' to "#####/..#../..#../..#../..#../..#../..#..",
    'U' to "#...#/#...#/#...#/#...#/#...#/#...#/.###.",
    'V' to "#...#/#...#/#...#/#...#/#...#/.#.#./..#..",
    'W' to "#...#/#...#/#...#/#.#.#/#.#.#/##.##/#...#",
    'X' to "#...#/#...#/.#.#./..#../.#.#./#...#/#...#",
    'Y' to "#...#/#...#/.#.#./..#../..#../..#../..#..",
    'Z' to "#####/....#/...#./..#../.#.../#..../#####",
    '0' to ".###./#...#/#..##/#.#.#/##..#/#...#/.###.",
    '1' to "..#../.##../..#../..#../..#../..#../.###.",
    '2' to ".###./#...#/....#/...#./..#../.#.../#####",
    '3' to "#####/...#./..#../...#./....#/#...#/.###.",
    '4' to "...#./..##./.#.#./#..#./#####/...#./...#.",
    '5' to "#####/#..../####./....#/....#/#...#/.###.",
    '6' to "..##./.#.../#..../####./#...#/#...#/.###.",
    '7' to "#####/....#/...#./..#../.#.../.#.../.#...",
    '8' to ".###./#...#/#...#/.###./#...#/#...#/.###.",
    '9' to ".###./#...#/#...#/.####/....#/...#./.##..",
    ':' to "...../..#../..#../...../..#../..#../.....",
    '.' to "...../...../...../...../...../.##../.##..",
    '-' to "...../...../...../.###./...../...../.....",
)

private val ROWS: Map<Char, List<String>> = GLYPHS.mapValues { entry -> entry.value.split("/") }

/** Text made of dots. With [shimmer] a soft brightness wave travels along it. */
@Composable
fun DotText(
    text: String,
    dot: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    shimmer: Boolean = false,
) {
    val t = text.uppercase()
    val phase: State<Float> = if (shimmer) {
        rememberInfiniteTransition(label = "dotShimmer").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
            label = "dotShimmerValue",
        )
    } else {
        remember { mutableStateOf(0f) }
    }

    Canvas(modifier.size(width = dot * max(6 * t.length - 1, 1), height = dot * 7)) {
        val pitch = dot.toPx()
        val radius = pitch * 0.36f
        val totalCols = (6 * t.length - 1).coerceAtLeast(1)
        var originCol = 0
        for (ch in t) {
            val rows = ROWS[ch] ?: ROWS[' ']!!
            for (r in 0 until 7) {
                val row = rows[r]
                for (c in 0 until 5) {
                    if (row[c] == '#') {
                        var a = 1f
                        if (shimmer) {
                            val x = (originCol + c).toFloat() / totalCols
                            a = 0.40f + 0.60f * (0.5f + 0.5f * sin(2.0 * PI * (phase.value - x)).toFloat())
                        }
                        drawCircle(
                            color = color.copy(alpha = a),
                            radius = radius,
                            center = Offset((originCol + c + 0.5f) * pitch, (r + 0.5f) * pitch),
                        )
                    }
                }
            }
            originCol += 6
        }
    }
}
